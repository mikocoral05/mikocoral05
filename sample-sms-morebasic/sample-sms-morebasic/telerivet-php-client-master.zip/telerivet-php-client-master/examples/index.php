<?php

$tr_lib_dir = dirname(dirname(__FILE__)) . '/telerivet.php';

?>
<html>
<body style='padding:30px'>
<ul>
<li><a href='send_sms.php'>Send am SMS message</a></li>
<li><a href='add_contact.php'>Add or update a Telerivet contact via a web form</a></li>
</ul>
</body>
</html>